<?php


session_start();
if (!isset($_SESSION['login'])) {
	$_SESSION['login']="incorreto";
}
if($_SESSION['login']=="correto"&& isset($_SESSION['login'])){
	//conteúdo



if ($_SERVER['REQUEST_METHOD']=="GET") {
	if (isset($_GET['prod'])&& is_numeric($_GET['prod'])) {
		$idproduto=$_GET['prod'];
		$con=new mysqli("localhost","root","","takeaway");

		if ($con->connect_errno!=0) {
				echo "<h1>Ocorreu um erro no acesso a base de dados.<br>".$connect_error."</h1>";
				exit();
		}
		$sql="Select * from produtos where id=?";
		$stm=$con->prepare($sql);
		if ($stm!=false) {
				$stm->bind_param("i",$idproduto);
				$stm->execute();
				$res=$stm->get_result();
				$prod=$res->fetch_assoc();
				$stm->close();
		}
	
				  ?>
	  <!DOCTYPE html>
	  <html>
	  <head>
	  	<title>Editar Produto</title>
	  </head>
	  <body>
	  <h1>Editar Produto</h1>




	  <form action="produtosupdate.php?prod=<?php  echo $prod['id']; ?>" method="post">
	<label>ID</label><input type="hidden" name="id" required value="<?php echo $prod['id'];?>"><br>
	<label>Restaurante</label><input type="text" name="id_restaurante" value="<?php echo $prod['id_restaurante'];?>"><br>
	<label>Produto</label><input type="text" name="produto" value="<?php echo $prod['produto'];?>"><br>
	<label>Preco</label><input type="text" name="preco" value="<?php echo $prod['preco'];?>"><br>



	
	<input type="submit" name="enviar">
</form>


	  </body>
	  </html>
	  <?php
	}	
else{
	echo ("<h1>houve um erro ao precessar o seu pedido.<br> Dentro de segundos sera reencaminhado!</h1>");
	header("refresh:5; url=index.php");
	}
	
	}


}
else{
	echo "Para entrar nesta página necessita de efetuar <a href='login.php'>login</a>";
	header('refresh:2;url=login.php');
}	
?>