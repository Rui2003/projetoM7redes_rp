<?php

if($_SERVER['REQUEST_METHOD']='POST'){
    $id="";
    $restaurante="";
    $produto="";
    $preco="";

    if (isset($_POST['id'])) {
        $id=$_POST['id'];
    }
    else{
        echo "<script>alert('É obrigatorio o preenchimento do id.');</script>";
    }
    if (isset($_POST['id_restaurante'])) {
        $id_restaurante=$_POST['id_restaurante'];   
    }
    if (isset($_POST['produto'])) {
        $produto=$_POST['produto'];
        
    }
    if (isset($_POST['preco'])) {
        $preco=$_POST['preco'];
        
    }

$con = new mysqli("localhost","root","","takeaway");

if($con->connect_errno!=0){
    echo "Ocorreu um erro no acesso à base de dados.<br>". $con->connect_error;
    exit;
}
else{
    $sql="update produtos set id_restaurante =? , produto =? , preco =? where id=?";
    $stm = $con->prepare ($sql);

    if($stm!=false){
        $stm->bind_param("issi",$id_restaurante,$produto,$preco, $id);
        $stm->execute();
        $stm->execute();
        $stm->close();

        echo '<script>alert("Produto alterado com sucesso!!");</script>';
        echo "Aguarde um momento.A reencaminhar página";
        header('refresh:5;url=index.php');

    }
    else{
}
    }
}
else{
    echo "<h1>Houve um erro ao processar o seu pedido! <br>Irá ser reencaminhado!</h1>";
    header("refresh:5; url=index.php");
}
